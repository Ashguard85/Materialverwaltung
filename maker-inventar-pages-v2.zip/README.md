# Maker Inventar · GitHub Pages PWA · v2

Statisches Zusatz-Frontend für **Maker Inventar Docker v2**. Dieses Repository enthält ausschließlich statische Dateien und GitHub-Actions-Workflows: kein Flask, kein Python-Backend, keine SQLite-Datei und keine serverseitigen Secrets.

## Betriebsmodi

### Lokal

- App-Shell aus Service-Worker-Cache
- strukturierte Fachdaten in IndexedDB (`maker-inventar-local`)
- kein Backend, keine Backend-URL, kein Cloudflare-Token
- nach erfolgreicher Installation/Cache-Befüllung weitgehend offline nutzbar
- JSON-Backup dringend empfohlen, da Website-/PWA-Daten auf dem Gerät verloren gehen können

### Server

- dieselbe UI und Fachlogik
- `ServerProvider` spricht per HTTPS mit dem Docker-Backend
- Backend URL + Cloudflare Service Token werden nur auf diesem Gerät in einer separaten IndexedDB (`maker-inventar-config`) gespeichert
- Service Secret wird nach Speicherung nicht wieder vollständig angezeigt
- Secrets sind nicht Bestandteil von Exporten/Backups

Ein Moduswechsel ändert **nur den aktiven Provider**. Es gibt keine automatische Synchronisation. Die Funktionen „Lokale Daten auf Server übertragen“ und „Serverdaten lokal übernehmen“ sind bewusst bestätigte Migrationen mit Vorschau; vor destruktiven Zieländerungen wird ein Sicherheitsbackup erzeugt bzw. exportiert.

## Gemeinsame Frontend-/Provider-Struktur

- `index.html`, `app.css`, `app.js`: gemeinsame UI/Fachlogik
- `providers.js`: `ServerProvider` und `LocalProvider`
- `db.js`: IndexedDB-Versionierung und getrennte Konfigurationsdatenbank
- `config.json`: einziges Build-spezifisches, nicht geheimes Runtime-Profil

Die gleichen Frontend-Dateien liegen im Docker-Paket unter `app/frontend/`. v2 ist Docker v2 ↔ Pages v2 kompatibel.

## Konfiguration

`config.json` darf **keine Secrets** enthalten. Optional können dort feste öffentliche Defaults eingetragen werden:

```json
{
  "appName": "Maker Inventar",
  "version": "v2",
  "buildTarget": "pages",
  "defaultMode": null,
  "defaultServerUrl": "https://api.example.com",
  "dockerWebUrl": "https://docker-app.example.com"
}
```

Bei leerer `defaultServerUrl` wird die Backend-URL im Setup eingegeben. Für externe Server erzwingt der Client HTTPS.

## Cloudflare Access / CORS

Für Server-Modus kann ein separates Cloudflare Access Service Token pro Gerät verwendet werden. Token eng berechtigen und bei Verlust des Geräts einzeln widerrufen.

Das Docker-Backend muss z. B. erhalten:

`PWA_ALLOWED_ORIGIN=https://app.example.com`

CORS-Preflight erlaubt die Cloudflare-Header nur von dieser exakten Origin. Cloudflare Access sollte für API-Zugriff eine passende Service-Auth-Policy besitzen; die normale Docker-Oberfläche kann parallel über OTP/Allow geschützt bleiben.

### CSP

GitHub Pages erlaubt keine frei konfigurierbaren Response-Header. Deshalb enthält `index.html` eine restriktive CSP als Meta-Policy: keine Inline-Scripts, keine Inline-Handler, kein `eval`, keine CDN-Abhängigkeiten. `connect-src https:` ist nötig, weil die Server-URL zur Laufzeit frei konfigurierbar ist. Bei fest gebauter Backend-URL kann diese Direktive projektspezifisch weiter eingeschränkt werden.

## Backup / Restore

Gemeinsames Format:

```json
{
  "format": "maker-inventar-backup",
  "version": 1,
  "data": {}
}
```

Enthalten sind Kategorien, Lagerorte, Bauteile, Projekte und Projektpositionen. Cloudflare- und App-Zugangsdaten werden nie exportiert.

Auf iPhone wird bei Dateiexport bevorzugt die Web Share API verwendet; ansonsten erfolgt ein Download-Fallback.

## Offline-App-Shell

`service-worker.js` precacht mindestens:

- `index.html`
- `app.js`, `app.css`, `db.js`, `providers.js`
- `config.json`
- `manifest.webmanifest`
- `offline.html`
- alle PWA-Icons

Es gibt keine externen Laufzeit-CDNs. Nach erfolgreichem ersten Online-Lauf kann die installierte App daher aus dem lokalen Cache starten, wenn GitHub Pages vorübergehend nicht erreichbar ist.

- Local-Modus: UI + IndexedDB funktionieren ohne Backend
- Server-Modus: gecachte UI kann weiterhin direkt die Docker-API ansprechen
- ist Docker nicht erreichbar, werden Schreibaktionen nicht als erfolgreich vorgetäuscht; v2 implementiert bewusst keine Offline-Schreibqueue

## PWA-Update-Lifecycle

Cache-Version: `maker-inventar-pwa-v2`.

- Browser/Client prüft auf neuen Service Worker
- neue App-Shell wird im Hintergrund in einem neuen versionsbezogenen Cache vorbereitet
- während der laufenden Sitzung wird **kein automatisches `skipWaiting()`** erzwungen
- keine automatische `location.reload()`-Kette bei `activate`/`controllerchange`
- „Jetzt aktualisieren“ setzt bewusst `SKIP_WAITING` und erlaubt genau einen Reload
- aktive Hauptansicht wird in `localStorage` behalten
- Local-IndexedDB und Server-Zugangsdaten werden von App-Updates nicht gelöscht

Für v2 muss `APP_VERSION`/Cache-Name in `service-worker.js`, `config.json` und Release-Dokumentation gemeinsam erhöht werden.

## Verhalten bei Hosting-Ausfall

Die App führt bei Pages-Builds gelegentlich einen expliziten Netzwerkcheck aus. Ist Pages nicht erreichbar, zeigt sie dezent an, dass die lokal installierte Version verwendet wird. Es erfolgt keine automatische Umleitung zur Docker-Oberfläche. Ein manueller Docker-Fallback kann über `dockerWebUrl` konfiguriert werden.

## ZIP-Import und Deployment

`import-zip.yml`:

1. reagiert auf genau ein neu hinzugefügtes Root-`*.zip`,
2. lehnt zusätzliche Root-Ebene, `.git`-Pfade und typische Secret-Dateien ab,
3. schützt den laufenden Import-Workflow,
4. ersetzt alte Dateien sauber,
5. entfernt das ZIP,
6. committet/pusht die neue Repository-Version,
7. veröffentlicht anschließend **im selben Workflow** GitHub Pages.

Der Bot-Commit wird nicht erneut importiert. Ein separater `deploy-pages.yml` veröffentlicht zusätzlich normale manuelle Änderungen auf `main`.

Das ZIP muss direkt das Repository-Root enthalten; keine zusätzliche Ordnerhülle.

## GitHub Pages Einrichtung

Im Repository unter **Settings → Pages** als Source **GitHub Actions** verwenden. Danach kann ein neues Release-ZIP ins Root des Repositories hochgeladen werden; der Import-Workflow übernimmt den Rest.

## Bekannte Einschränkungen v2

- keine echte Offline-/Server-Synchronisationsengine
- keine Konfliktauflösung nach Feldversionen; Merge arbeitet über stabile IDs
- keine Barcode-/Kameraerfassung
- keine Bilder/Datenblätter
- keine externe Lieferantensuche
- iOS kann Website-Daten unter bestimmten Systembedingungen verwalten/löschen; regelmäßige lokale Backups bleiben wichtig

## v2 UI-Update

v2 richtet die iPhone-Oberfläche am freigegebenen Mockup-Stil aus: großer Header, Status-Badge, Statistik-Karten, visuelle Bauteilkarten, Projekt-Fortschritt, Bottom-Sheet-Formulare und gruppierte Setup-Karten. Das Datenmodell und Backupformat bleiben gegenüber v1 kompatibel.

### Release-ZIP und `.gitignore`

Release-ZIPs enthalten absichtlich **keine `.gitignore`**. Der ZIP-Import-Workflow schließt `.gitignore` zusätzlich beim `rsync --delete` aus. Dadurch bleibt die bereits im Repository gepflegte `.gitignore` bei jedem ZIP-Update erhalten und kann vom Release weder überschrieben noch gelöscht werden.

### Einmaliger Übergang von v1 auf v2

Wenn das Repository bereits den v1-ZIP-Import-Workflow verwendet, muss `.github/workflows/import-zip.yml` **vor dem ersten v2-ZIP-Upload einmalig** durch die mit v2 gelieferte Workflow-Version ersetzt werden. Grund: Der v1-Workflow schützt sich selbst und kann daher per Release-ZIP nicht aktualisiert werden; gleichzeitig kennt er den neuen `.gitignore`-Exclude noch nicht. Ab dem v2-Workflow bleibt `.gitignore` bei jedem `rsync --delete` unangetastet.

Für neue Repositories liegt `.gitignore.example` als Vorlage bei. Die echte `.gitignore` wird bewusst nicht als Release-Datei ausgeliefert.
